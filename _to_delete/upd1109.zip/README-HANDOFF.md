# VATEK 홈페이지 업데이트 — 2026-11-09 (Claude 디자인 세션 v124 → v145)

이 폴더는 GitHub 저장소 **swchang123/vatek-site** 에 그대로 덮어쓰는 변경 묶음입니다.
경로 구조가 저장소와 같습니다 (`index.html`, `assets/…`, `products/…` 등).

> **기준 커밋**: 이 묶음은 GitHub `main`의 최신 커밋 **9385d61** (2026-11-07 23:53 KST, 메시지 "111") 과 비교해 만들었습니다.
> 그 커밋에는 2026-11-07 업데이트(vatek-site-update-2026-11-07.zip)가 이미 반영되어 있음을 확인했습니다.
> 따라서 이 묶음 **하나만** 적용하면 디자인 세션의 최신 상태(v145)와 저장소가 같아집니다.

---

## 1. Claude Code에게 맡길 때 — 그대로 붙여 넣을 요청문

```
vatek-site 저장소 폴더에서 작업해줘.
1) git status 로 작업 트리가 깨끗한지, git log -1 로 HEAD가 9385d61 인지 확인해줘.
   - HEAD가 다르거나 수정 중인 파일이 있으면 멈추고 알려줘 (덮어쓰기 전에 내가 판단할게).
2) 이 zip(vatek-site-update-2026-11-09.zip)을 풀어서 안의 vatek-site-update-2026-11-09/ 폴더 내용을
   저장소 루트에 덮어써줘. 단, README-HANDOFF.md, CHANGES-2026-11-09.patch, MANIFEST-md5.txt 는 복사하지 마.
3) MANIFEST-md5.txt 로 복사된 66개 + 신규 3개 파일의 md5 가 모두 일치하는지 확인해줘.
4) git status 로 변경 파일 목록을 보여주고 (69개여야 함: 수정 66, 신규 3),
   git add -A && git commit -m "히어로 배지·문구·가독성·성능 개선, 펠릿타이저 찾기 결과 개편 (2026-11-09)" && git push 해줘.
5) 1~2분 뒤 https://swchang123.github.io/vatek-site/products/pelletizer/ 에서
   '생산 시스템 찾기' 결과의 제품 보러가기 / 다시하기 / 출력하기 버튼이 동작하는지 확인해줘.
```

## 2. 직접 적용할 때

1. zip을 풀고 `vatek-site-update-2026-11-09/` 안의 파일들을 저장소 루트에 덮어씁니다
   (README-HANDOFF.md, CHANGES-2026-11-09.patch, MANIFEST-md5.txt 세 파일은 저장소에 넣지 않아도 됩니다).
2. 저장소 폴더에서
   ```
   git status
   git add -A
   git commit -m "히어로 배지·문구·가독성·성능 개선, 펠릿타이저 찾기 결과 개편 (2026-11-09)"
   git push
   ```
3. 배포 후 브라우저 캐시 때문에 **Ctrl+F5** 로 새로고침해서 확인하세요.

## 3. 묶음 구성 (69개 파일)

| 구분 | 수 | 내용 |
|---|---|---|
| 수정 HTML | 60 | index.html, applications/ 10, cases/ 4, cleaning/ 5, company/ 3, industries/ 22, products/ 7, rental/ 5, support/ 3 |
| 수정 CSS | 5 | assets/css/style.css, pelletizer-page.css, recovery-page.css, supply-page.css, vrental-page.css |
| 수정 JS | 1 | assets/js/main.js |
| **신규** | 3 | `products/pelletizer/print.html` (출력 전용 페이지), `assets/img/rule-pan-v2.webp` (비교 페이지 프라이팬 사진), `assets/img/blaster-pcs-60-white.webp` |

- `CHANGES-2026-11-09.patch` : 텍스트 파일(HTML/CSS/JS)의 변경 내용 diff (HEAD 9385d61 기준). 검토용이며, 파일을 덮어쓰면 patch는 적용할 필요 없습니다.
- `MANIFEST-md5.txt` : 69개 파일의 md5. 복사 검증용.
- 이미지 3개(`pelletizer-hero-poster.webp`, `plt-card-rseries.webp`, `rule-pan.webp`)는 저장소와 바이트가 조금 다르지만 **픽셀이 완전히 동일**해서 묶음에서 제외했습니다.

## 4. 변경 내용 요약 (2026-11-07 업데이트 이후)

### 전 페이지 공통
- **Cold Jet × VATEK 배지**: 모든 히어로 이미지/영상 우측 하단에 같은 위치·같은 크기로 배치 (약 60개 페이지). 반투명 흰 박스 축소, 로고 10% 축소. 스크롤 시 본문과 함께 올라가며 사라짐 (`main.js` `subheroBadge`/`heroBadge`).
- **위로가기(TOP) 버튼** 전 페이지 적용 (`main.js` IIFE, `style.css`).
- **보이지 않던 글씨 수정**: 어두운 컨테이너 안의 밝은 파랑(`--ice`) 텍스트를 진한 파랑으로, `.auto-feature` 등 sticky 형제 흰 배경 규칙에서 제외. 96개 페이지 대비(contrast) 자동 검사로 확인.
- **히어로 강조어**(`.bls-hero-accent`)는 번짐(glow) 대신 단색 연파랑(#8db3f2)으로.
- 스크롤 성능: 화면 밖 무한 애니메이션 일시정지(`.anim-off`), 대면적 그라데이션 제거, width 대신 transform 사용.

### 메인/블라스터 (`products/blaster/index.html`, `aero2-*.html`)
- 마지막 CTA: 제목 "장비를 결정하기 전에, / 실제 오염 제품으로 확인해보세요.", 새 문단, **세척테스트 신청 / 장비 렌탈 신청 / 장비 상담** 파란 버튼 3개 (호버 효과). "렌탈과 데모 보기", 제품 영상 안내 문장 삭제.
- 스크롤 버벅임 개선(paint 비용 대폭 감소) — "잡고 돌려보세요" 손가락 모션은 유지.
- aero2 페이지 pill 라벨 글자색 흰색.

### 타 세척방식과의 비교 (`cleaning/compare.html`)
- 우측 레일 숫자에 작업별 솔루션과 같은 방식의 툴팁(`data-title`).
- 히어로 제목 "강력한 세척보다, / 공정에 적합한 세척이 중요합니다." 및 본문 교체.
- 설거지 사진 → 첨부 프라이팬 사진(`rule-pan-v2.webp`, 웹 용량 최적화).

### 펠릿타이저 (`products/pelletizer/index.html`, `pelletizer-page.css`)
- "01" 장식 숫자 제거, 카드 제목 "필요한 만큼만 생산", 카드 하단 파란 선 호버.
- 히어로 제목: "용도에 적합한 드라이아이스를, / 필요할 때, 필요한 만큼 생산하고 / 바로 사용할 수 있습니다." (3줄 유지되도록 글자 크기/폭 조정).
- 생산 시스템 찾기 **각 단계 제목을 질문형**으로 변경 (01 원하는 드라이아이스 형태가 무엇인가요? … 04 계획하고 계신 시간당 생산량을 알려주세요.).
- **찾기 결과 패널 개편**:
  - 카드마다 **장비 실물 사진 → 모델명 → "제품 보러가기" 버튼** (각 모델 상세 페이지로 연결. R500H/R1000H/R2000H 는 `plt-r*-g1.webp` 제품 사진 사용, Production Hub 는 production-hub.html, 맞춤 검토 결과는 견적 페이지로 가는 외곽선 버튼 "상담 문의").
  - 하단 "상세 보기" 버튼 → **다시하기** (초기화 후 찾기 카드를 화면 세로 중앙으로 부드럽게 스크롤) + **출력하기**.
  - **출력하기**: 브라우저 기본 인쇄 미리보기로 A4 1장짜리 결과지(제목·날짜, 선택 조건 4칸, 추천 장비 카드, NOTE, 회사 표기)만 인쇄. 인쇄 창이 차단된 환경(디자인 미리보기 프레임 등)에서는 자동으로 `products/pelletizer/print.html` 을 새 탭으로 열어 거기서 인쇄. 새 탭도 막히면 버튼 옆에 "새 탭에서 출력 페이지 열기" 링크 표시.
  - 모바일에서 카드 세로 배치, 버튼 폭 분할.

### 기타
- `recovery-page.css`, `supply-page.css`, `vrental-page.css`: 어두운 배경 위 글자색 보정, `.vr-model-media .tag` z-index.
- 서브 히어로 eyebrow 색상(`--ice-on-dark`), `.cmp-rail` 툴팁 규칙 등 `style.css` 말미에 추가.

## 5. 주의
- `assets/css/style.css`, `assets/js/main.js`, `products/pelletizer/index.html` 은 변경량이 큽니다. 로컬에서 이 파일들을 따로 고친 적이 있다면 덮어쓰기 전에 `CHANGES-2026-11-09.patch` 로 내용을 확인하세요.
- `products/pelletizer/index.html` 의 `<link … pelletizer-page.css?v=20261015-2>` 캐시 버스터는 그대로입니다. 배포 후 스타일이 예전 것으로 보이면 Ctrl+F5.
