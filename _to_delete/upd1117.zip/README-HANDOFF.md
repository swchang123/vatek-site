# VATEK 홈페이지 업데이트 — 2026-11-17

이 폴더는 GitHub 저장소 **swchang123/vatek-site** 에 그대로 덮어쓰는 변경 묶음입니다.
경로 구조가 저장소와 같습니다 (`index.html`, `assets/…`, `products/…` 등).

> **기준 커밋**: GitHub `main` 의 최신 커밋 **b874fa9** (2026-11-09 13:24 KST, 메시지 "111") 과 비교해 만들었습니다.
> **디자인 기준**: Claude 디자인 세션의 2026-11-17 현재 게시 상태 (버전 id `1794889742-0b9f`).
> 이 묶음 **하나만** 적용하면 저장소의 화면이 디자인 세션의 현재 화면과 같아집니다.

---

## 1. Claude Code에게 맡길 때 — 그대로 붙여 넣을 요청문

```
vatek-site 저장소 폴더에서 작업해줘.
1) git status 로 작업 트리가 깨끗한지, git log -1 로 HEAD가 b874fa9 인지 확인해줘.
   - HEAD가 다르거나 수정 중인 파일이 있으면 멈추고 알려줘 (덮어쓰기 전에 내가 판단할게).
2) 이 zip(vatek-site-update-2026-11-17.zip)을 풀어서 안의 vatek-site-update-2026-11-17/ 폴더 내용을
   저장소 루트에 덮어써줘. 단, README-HANDOFF.md, CHANGES-2026-11-17.patch, MANIFEST-md5.txt 는 복사하지 마.
   이 묶음에 없는 파일(특히 assets/video 의 영상, 다른 이미지)은 건드리지 마.
3) MANIFEST-md5.txt 로 복사된 104개 파일의 md5 가 모두 일치하는지 확인해줘.
4) git status 로 변경 파일 목록을 보여줘. 104개여야 해 (수정 90, 신규 14). 숫자가 다르면 멈추고 알려줘.
5) 맞으면 git add -A && git commit -m "렌탈, 장비 비교 추천, 펠렛타이저 찾기 개편 및 히어로 통일 (2026-11-17)" && git push 해줘.
6) 1~2분 뒤 아래 페이지를 열어 확인해줘.
   - https://swchang123.github.io/vatek-site/rental/vrental.html  (자가 체크 3문항, 결과 패널)
   - https://swchang123.github.io/vatek-site/products/compare-equip.html  (추천 결과에 제품 사진이 보이는지)
   - https://swchang123.github.io/vatek-site/cleaning/guide.html  (히어로 우측 하단 로고 박스와 본문 사이 간격)
```

## 2. 직접 적용할 때

1. zip을 풀고 `vatek-site-update-2026-11-17/` 안의 파일들을 저장소 루트에 덮어씁니다
   (README-HANDOFF.md, CHANGES-2026-11-17.patch, MANIFEST-md5.txt 세 파일은 저장소에 넣지 않습니다).
2. 저장소 폴더에서
   ```
   git status
   git add -A
   git commit -m "렌탈, 장비 비교 추천, 펠렛타이저 찾기 개편 및 히어로 통일 (2026-11-17)"
   git push
   ```
3. 배포 후 브라우저 캐시 때문에 **Ctrl+F5** 로 새로고침해서 확인하세요.

## 3. 묶음 구성 (104개 파일)

| 구분 | 수 | 내용 |
|---|---|---|
| 수정 HTML | 73 | index.html, applications/ 10, cases/ 4, cleaning/ 5, company/ 3, industries/ 22, products/ 20, rental/ 5, support/ 3 |
| 수정 CSS | 6 | assets/css/ 의 style.css, compare-equip-page.css, nozzle-page.css, pelletizer-page.css, recovery-page.css, vrental-page.css |
| 수정 JS | 2 | assets/js/ 의 main.js, compare-equip.js |
| 수정 사진 | 9 | assets/img/ 의 coldjet-hq-photo-1~4.jpg, vatek-coldjet-photo-1~5.jpg (아래 4번 참고) |
| **신규 이미지** | 14 | assets/img/ 의 blaster-…-thumb.webp 11개 (비교표 제품 썸네일), compare-hero.jpg, guide-hero-work.jpg, vrental-logo-white.png |

- `CHANGES-2026-11-17.patch` : 텍스트 파일 81개(HTML, CSS, JS)의 변경 내용 diff (b874fa9 기준). 검토용이며, 파일을 덮어쓰면 patch는 적용할 필요가 없습니다.
- `MANIFEST-md5.txt` : 104개 파일의 md5. 복사 검증용.

## 4. 디자인과 저장소를 비교한 방법, 그리고 일부러 넣지 않은 것

HTML, CSS, JS는 사이트의 모든 파일(HTML 97, CSS 18, JS 5)을 디자인에서 내려받아 저장소와 1바이트 단위로 비교했고, 다른 파일 81개를 전부 넣었습니다. 적용 후에는 이 파일들이 디자인과 완전히 같습니다.

이미지와 영상은 저장소 쪽에 이미 용량을 줄인 사본이 올라가 있어서 다음 기준으로 골랐습니다.

- **넣은 것 (화면이 달라지는 경우)**
  - 저장소에 없는 이미지 14개. 이 중 `vrental-logo-white.png` 는 메가메뉴의 V렌탈 항목에 쓰는 흰색 로고인데, 저장소에 없어서 현재 라이브 사이트에서는 깨진 이미지로 나옵니다.
  - 사진 9개. 저장소 사본은 세로 260px로 줄여져 있는데 화면에서는 최대 690×431px로 표시되어 디자인보다 흐립니다. 디자인과 같은 픽셀 크기의 파일로 넣었습니다.
    `coldjet-hq-photo-1~4.jpg` 는 디자인 파일 그대로이고, `vatek-coldjet-photo-1~5.jpg` 는 디자인 파일이 실제로는 PNG 데이터(합계 3.4MB)여서 같은 픽셀 크기의 JPEG(품질 93, 합계 0.7MB)로 저장했습니다. 눈으로 구분되는 차이는 없습니다.
- **넣지 않은 것 (화면이 같은 경우)**
  - 영상 7개 (blaster-hero, pelletizer-definition, pelletizer-ondemand, pcs-demo-asphalt, pcs-demo-namecard, automation-vatek-line, recovery-process). 저장소 사본이 해상도와 길이는 같고 비트레이트만 낮춘 것입니다 (예: 15.7MB → 1.5MB). 디자인 원본으로 덮으면 용량만 커집니다.
  - `vatek-building.jpg`. 저장소 사본이 같은 크기(1897×880)의 재압축본입니다 (1.57MB → 0.16MB).
  - 이미지 211개. 디자인 파일에만 C2PA 메타데이터(파일당 약 5.8KB)가 붙어 있고 그림은 같습니다. 50개는 픽셀 단위로 비교해 완전히 같음을 확인했고, 나머지 161개는 파일 크기 차이가 그 메타데이터 크기와 정확히 같습니다.
  - 그 밖의 이미지와 PDF는 파일 크기(또는 내용)가 저장소와 같아 같은 파일로 보았습니다.
- 저장소에만 있는 영상 13개(compare-equip-hero.mp4, process-hero.mp4 등)와 그 밖의 파일은 그대로 둡니다. 삭제할 파일은 없습니다.

## 5. 2026-11-09 이후 달라진 내용

- **V렌탈 페이지**: 히어로 문구, 자가 체크(3문항, 결과 패널, 사용 빈도와 기간 조합으로 판정), 렌탈 진행 5단계, 디젤 콤프레샤 안내(파트너사 유상 렌탈, 참고용 이미지 표기)
- **장비 비교, 추천받기**: 찾기 화면 재구성(클릭하면 다음 질문으로 진행, 선택 칩으로 되돌아가기), 1순위와 함께 검토할 장비 추천, 렌탈 버튼은 렌탈 가능한 4종에만 표시, 비교표 제품 썸네일, 히어로와 제목 문구
- **펠렛타이저 생산 시스템 찾기**: 화면 재구성, 결과를 같은 카드 안에 표시, 출력 페이지 문구
- **모든 서브 페이지 히어로**: 텍스트 박스 크기 통일(60개 페이지), 우측 하단 Cold Jet × VATEK 로고 박스와 본문 사이 간격 통일
- **세척 가이드 계열**: '관련 페이지' 버튼, 섹션 번호 크기
- **블라스터 모델 페이지와 노즐 페이지**: 대표 노즐 안내와 장비별 노즐 바로가기
- 렌탈, 장비 비교 추천, 펠렛타이저 찾기 3개 화면의 본문에서 가운뎃점 제거

## 6. 적용 전 검증한 것

- 저장소(b874fa9)에 이 묶음을 덮어쓴 상태를 로컬에서 띄워 97개 페이지를 모두 열었습니다. 불러오지 못하는 파일(404)과 스크립트 오류가 없었습니다.
- `git status` 기준 수정 90, 신규 14, 합계 104개임을 확인했습니다.

## 7. 디자인에도 원래 있는 문제 (이번 묶음으로 달라지지 않음)

- 산업별 페이지 19곳의 `applications/facility-maintenance.html` 링크는 대상 페이지가 디자인과 저장소 양쪽에 없습니다.
- 사례 목록(cases)의 카드가 여는 `cases/detail.html`, `cases/watch.html` 도 양쪽에 없습니다.
